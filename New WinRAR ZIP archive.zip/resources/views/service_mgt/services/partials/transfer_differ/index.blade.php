<div class="slugs">
    <div class="sub-head">
        Transfer (Differ)
    </div>
<input type="hidden" id="transfer_id" name="transfer_id" value="{{isset($process->transfer->id) ? $process->transfer->id : ''}}">
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <div class="form-col-2 text-left">
                    <label for="" class="control-label">Transfer Differ To</label>
                </div>
                <div class="form-col-10">    
                    <select name="transfer_to" id="transfer_to" class="form-control form-control-sm" {{isset($process->transfer) ? "disabled" : ''}}>
                        <option value="">--Select Institution--</option>
                        @foreach ($institutes as $institute)
                        <option value="{{ $institute->id}}" {{(isset($process->transfer) && $process->transfer->transfer_to == $institute->id)  ? 'selected' : ''}}>{{ $institute->institute}} </option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="form-group">
                <div class="form-col-2 text-left">
                    <label for="" class="control-label">Transfer Type</label>
                </div>
                <div class="form-col-10">    
                    <select name="transfer_type" id="transfer_type" class="form-control form-control-sm" {{isset($process->transfer) ? "disabled" : ''}}>
                        <option value="" @if(isset($process->transfer) && $process->transfer->transfer_type==""){{"selected"}} @endif >--Select Tranfer Type--</option>
                        <option value="0" @if(isset($process->transfer) && $process->transfer->transfer_type==0){{"selected"}} @endif >Service Need</option>
                        <option value="1" @if(isset($process->transfer) && $process->transfer->transfer_type==1){{"selected"}} @endif >Temprory</option>
                        <option value="2" @if(isset($process->transfer) && $process->transfer->transfer_type==2){{"selected"}} @endif >2:3 Days</option>
                        <option value="3" @if(isset($process->transfer) && $process->transfer->transfer_type==3){{"selected"}} @endif >Annual</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-3">
            <div class="form-group">
                <div class="form-col-2 text-left">
                    <label for="" class="control-label">Effective From</label>
                </div>
                <div class="form-col-3">    
                    <input type="date" class="form-control form-control-sm" name="effect_from" id="effect_from" value="{{isset($process->transfer) ? $process->transfer->effect_from : ''}}" {{isset($process->transfer) ? "disabled" : ''}}>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            @if(isset($process->transfer))
                <a href="{{route('process.print_transfer',$process->transfer->id)}}" target="_blank" class="btn btn-primary btn-sm float-left" data-toggle="tooltip" data-placement="bottom" title="Add User"><i class="fa fa-print"></i> Print Letter</a>
            @endif
        </div>
    </div>
</div>

<style>
.slugs{
    position:relative;
    padding:20px;
    box-shadow: rgba(0, 0, 0, 0.02) 0px 1px 3px 0px, rgba(27, 31, 35, 0.15) 0px 0px 0px 1px;
}
.sub-head{
    border:1px solid;
    position:absolute;
    border-radius: 5px;
    padding: 5px;
    left:20px;
    top:-10px;
    z-index:99;
    color: white;
    background-color: green;
}
</style>