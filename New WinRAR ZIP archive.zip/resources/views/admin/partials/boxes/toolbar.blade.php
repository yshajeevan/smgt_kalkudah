<div class="float-right card-tools">
    <button type="button" class="btn {{ isset($btnDateClass)? $btnDateClass: 'btn-primary' }}  btn-sm daterange" data-toggle="tooltip" title="Date Range">
        <i class="fa fa-calendar"></i>
    </button>

    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
        <i class="fas fa-minus"></i>
    </button>
</div>

@push('styles')
<style>
   
</style>
@endpush