<?php

/**
 * Set your google api key.
 */
return [
    'api_key' => env('GOOGLE_MAPS_DISTANCE_API_KEY'),
];
