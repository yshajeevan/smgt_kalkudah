<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Employee;
use auth;
class WebNotificationController extends Controller
{
  
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        return view('home');
    }
  
    public function storeToken(Request $request)
    {
        auth()->user()->update(['device_key'=>$request->token]);
        return response()->json(['Token successfully stored.']);
    }
    
    public function sendWebNotification(Request $request)
    {
        //Firebase Notification
        $url = 'https://fcm.googleapis.com/fcm/send';
        $FcmToken = Employee::where('id','=',1528)->pluck('device_key');

        $serverKey = 'AAAAPlyPkn4:APA91bHTfxIwVm6rquyBGGUcVkhsxKiylVfwYX1MIqDpZ_TiT0tJcj4eqOnn-xsJ36f7KRg0MXNm0_5k7uilalJtUTpJdl4A72hL4RaFRCfOmp6ALotbPABM81Ro5oPPCmfa-lt9ki95';
  
        $data = [
            "registration_ids" => $FcmToken,
            "notification" => [
                "title" => 'SMGT_Service',
                "body" => 'Welcome2',   
            ]
        ];
        $encodedData = json_encode($data);
    
        $headers = [
            'Authorization:key=' . $serverKey,
            'Content-Type: application/json',
        ];
    
        $ch = curl_init();
      
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);        
        curl_setopt($ch, CURLOPT_POSTFIELDS, $encodedData);
        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }        
        // Close connection
        curl_close($ch);
        // FCM response
        dd($result);      
    }
}