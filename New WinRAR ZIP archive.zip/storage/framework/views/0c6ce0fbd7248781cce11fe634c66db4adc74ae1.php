<?php $__env->startSection('main-content'); ?>
<div class="card shadow mb-4">
  <div class="row">
    <div class="col-md-12">
      <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>

  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary float-left">
        <?php echo e(isset($checklist) ? "Edit Checklist" : "Add Checklist"); ?>

    </h6>
  </div>

  <div class="card-body">
    <form action="<?php echo e(isset($checklist) ? route('checklist.update',$checklist->id) : route('checklist.store')); ?>"
          method="post"
          enctype="multipart/form-data">

        <?php echo csrf_field(); ?>
        <?php if(isset($checklist)): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        
        <div class="row">
            <div class="col-md-12">
                <div class="form-group text-dark">
                    <label>Document Name</label>
                    <input type="text"
                           class="form-control"
                           name="name"
                           value="<?php echo e(old('name', isset($checklist) ? $checklist->name : '')); ?>">
                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-md-12">
                <div class="form-group text-dark">
                    <label>Upload Supportive Document (Optional)</label>
                    <input type="file" name="supportive_doc" class="form-control">
                </div>

                
                <?php if(isset($checklist) && $checklist->supportive_doc): ?>

                <?php
                    $extension = pathinfo($checklist->supportive_doc, PATHINFO_EXTENSION);
                ?>

                <a href="<?php echo e(asset($checklist->supportive_doc)); ?>" target="_blank">
                    <?php if(in_array(strtolower($extension), ['jpg','jpeg','png','gif'])): ?>
                        
                        <img src="<?php echo e(asset('images/pdf-icon.png')); ?>"
                            width="60"
                            style="border:1px solid #ccc;padding:3px;">
                    <?php elseif($extension == 'pdf'): ?>
                        
                        <img src="<?php echo e(asset('images/pdf-icon.png')); ?>"
                            width="40">
                    <?php elseif(in_array(strtolower($extension), ['doc','docx'])): ?>
                        
                        <img src="<?php echo e(asset('images/word-icon.png')); ?>"
                            width="40">
                    <?php else: ?>
                        
                        <img src="<?php echo e(asset('images/file-icon.png')); ?>"
                            width="40">
                    <?php endif; ?>
                </a>
            <?php endif; ?>
            </div>
        </div>

        
        <div class="row">
            <div class="col-md-12">
                <div class="form-group text-dark">
                    <label>Remarks</label>
                    <input type="text"
                           class="form-control"
                           name="remarks"
                           value="<?php echo e(old('remarks', isset($checklist) ? $checklist->remarks : '')); ?>">
                </div>
            </div>
        </div>

        
        <input type="hidden"
               name="service_id"
               value="<?php echo e(isset($checklist) ? $checklist->service_id : $id); ?>">

        <div class="mt-3">
            <input type="submit"
                   class="btn btn-warning"
                   value="<?php echo e(isset($checklist) ? 'Update' : 'Add'); ?>">
        </div>

    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\VS Projects\SMGT\resources\views/service_mgt/services/checklist_createOrUpdate.blade.php ENDPATH**/ ?>