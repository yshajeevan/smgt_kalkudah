<?php $__env->startSection('main-content'); ?>
<div class="card shadow mb-4">
     <div class="row">
         <div class="col-md-12">
            <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
     </div>

    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">
          Service Checklist - <?php echo e($service->service); ?>

      </h6>
    </div>

    <div class="card-body">
        <div class="checklist-wrapper">

            <?php $__currentLoopData = $checklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row align-items-start">
                
                <div class="col-8">

                    <div class="mb-2">
                        
                        <strong><?php echo e($loop->iteration); ?>.</strong>

                        
                        <?php echo e($checklist->name); ?>


                        
                        <?php if($checklist->supportive_doc): ?>

                            <?php
                                $extension = strtolower(pathinfo($checklist->supportive_doc, PATHINFO_EXTENSION));
                            ?>

                            <a href="<?php echo e(asset($checklist->supportive_doc)); ?>" target="_blank" style="margin-left:10px;">

                                <?php if(in_array($extension, ['jpg','jpeg','png','gif'])): ?>
                                    <img src="<?php echo e(asset('images/image-icon.png')); ?>"
                                         width="40"
                                         style="border:1px solid #ccc;padding:2px;">
                                <?php elseif($extension == 'pdf'): ?>
                                    <img src="<?php echo e(asset('images/pdf-icon.png')); ?>" width="25">
                                <?php elseif(in_array($extension, ['doc','docx'])): ?>
                                    <img src="<?php echo e(asset('images/word-icon.png')); ?>" width="25">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('images/file-icon.png')); ?>" width="25">
                                <?php endif; ?>

                            </a>
                        <?php endif; ?>
                    </div>

                    
                    <?php if($checklist->remarks): ?>
                        <div style="margin-left:25px;">
                            <b><i>(<?php echo e($checklist->remarks); ?>)</i></b>
                        </div>
                    <?php endif; ?>

                </div>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-create')): ?>
                <div class="col-2">
                    <a href="<?php echo e(route('checklist.edit',$checklist->id)); ?>"
                       class="btn btn-xs btn-primary btn-sm"
                       style="height:30px; width:30px;"
                       title="Edit">
                        <i class="fas fa-edit"></i>
                    </a>

                    <form action="<?php echo e(route('checklist.destroy', $checklist->id)); ?>"
                        method="POST"
                        style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit"
                                class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure?')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </div>
                <?php endif; ?>

            </div>
            <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('service-create')): ?>
            <a href="<?php echo e(route('checklist.create',$id)); ?>"
               class="btn btn-primary btn-sm float-left">
               <i class="fas fa-plus"></i> Add Checklist
            </a>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.card{
    height:600px;
}
.checklist-wrapper ul{
    list-style-type:none;
    padding-left:20px;
    color:#666;
}
.checklist-wrapper li{
    position: relative;
    padding-left:20px;
    margin-bottom:10px;
}




</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\VS Projects\SMGT\resources\views/service_mgt/services/checklist_show.blade.php ENDPATH**/ ?>