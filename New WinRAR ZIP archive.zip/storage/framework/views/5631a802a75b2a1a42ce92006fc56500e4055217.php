<?php
    $template = Auth::user()->hasAnyRole(['Sch_Admin']) ? 'layouts.school.master' : 'layouts.master';
?>



<?php $__env->startSection('main-content'); ?>
<div class="card shadow mb-4">
     <div class="row">
         <div class="col-md-12">
            <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
     </div>
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Request for Employee's Updation</h6>
    </div>
    <div class="card-body">
    <?php if(Auth::user()->roles->pluck('name')->implode(', ') != 'Sch_Admin'): ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-3">
                    <div class="form-group">
                        <label><strong>Institute :</strong></label>
                        <select name="institute" id="institute" class="form-control form-control-sm">
                            <option value="">--Select Institute--</option>
                            <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($institute->id); ?>" <?php echo e((isset($employee) && $employee->institute_id == $institute->id)  ? 'selected' : ''); ?>><?php echo e($institute->institute); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="form-group">
                        <label><strong>Filter by Designation :</strong></label>
                        <select name="designation" id="designation" class="form-control form-control-sm">
                            <option value="">--Select Designation--</option>
                            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($designation->id); ?>" <?php echo e((isset($employee) && $employee->designation_id == $designation->id)  ? 'selected' : ''); ?>><?php echo e($designation->designation); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="form-group">
                        <label><strong>Filter by Cadre :</strong></label>
                        <select name="cadre" id="cadre" class="form-control form-control-sm">
                            <option value="">--Select Cadre Subject--</option>
                            <?php $__currentLoopData = $cadresubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadresub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cadresub->id); ?>" <?php echo e((isset($employee) && $employee->cadresubject_id == $cadresub->id)  ? 'selected' : ''); ?>><?php echo e($cadresub->cadre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-create')): ?>
    <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-primary btn-sm float-right" data-toggle="tooltip" data-placement="bottom" title="Add User"><i class="fas fa-plus"></i> Add Employee</a>
    <a href="<?php echo e(route('employee.export')); ?>" class="btn btn-primary btn-sm float-right" data-toggle="tooltip" data-placement="bottom" title="Export"><i class="fa fa-file-excel-o"></i> Bulk Export</a>
    <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered" id="emp_approval">
                <thead>
                    <th>Id</th>
                    <th>Name</th>
                    <th style="width:300px;">Institute</th>
                    <th>Designation</th>
                    <th>Cadre</th>
                    <th>Status</th>
                    <th>Options</th>
                </thead>				
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function () {
    var table = $('#emp_approval').DataTable({
        processing: true,
        serverSide: true,
        stateSave:true,
        dom: '<"dt-buttons"Bf><"clear">lirtp',
        paging: true,
        autoWidth: true,
        buttons: [
				'colvis',
				'copyHtml5',
				'excelHtml5',
                'pdfHtml5',
				'print'
			    ],
        ajax: {
          url: "<?php echo e(route('employee.dummy_index')); ?>",
          data: function (d) {
                _token: "<?php echo e(csrf_token()); ?>",
                d.cadre = $('#cadre').val(),
                d.institute = $('#institute').val(),
                d.designation = $('#designation').val(),
                d.transferValidate = $('#transferValidate').val(),
                d.search = $('input[type="search"]').val()
            }
        },
        columns: [
            {data: 'employee_id', name: 'employee_id'},
            {data: 'surname', name: 'surname'},
            {data: 'institute', name: 'institute.institute'},
            {data: 'designation', name: 'designation.designation'},
            {data: 'cadresubject', name: 'cadresubject.cadre'},
            {data: 'status', name: 'status',
                render: function (data, type, full, meta) {
                    if(data == 'Active'){
                        return "<p class='badge rounded-pill bg-success text-light'>" + data + "</p>";
                    } else {
                        return "<p class='badge rounded-pill bg-danger text-light'>" + data + "</p>";
                    }
                }
            },
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
        
        
    });
    let column = table.column(2);
    let user = '<?php echo e(Auth::user()->roles->pluck('name')->implode(', ')); ?>';
    if(user === 'Sch_Admin'){
        column.visible(false);
    } else{
        column.visible(true);
    }
    
    $('#cadre').change(function(){
        table.draw(); 
    });
    $('#designation').change(function(){
        table.draw(); 
    });
    $('#institute').change(function(){
        table.draw(); 
    });
    $('#transferValidate').change(function(){
        table.draw(); 
    });
});
$('#emp_approval').on('click', '.btn-delete[data-remote]', function (e) { 
    e.preventDefault();
     $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    var url = $(this).data('remote');
    console.log(url);
    // confirm then
    if (confirm('Are you sure you want to delete this record?')) {
        $.ajax({
            url: url,
            type: 'DELETE',
            dataType: 'json',
            data: {method: '_DELETE', submit: true}
        }).always(function (data) {
            $('#emp_approval').DataTable().draw(false);
        });
    }else{
        alert("You have cancelled!");
    }
    
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($template, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\VS Projects\SMGT\resources\views/human_resource/dummy_index.blade.php ENDPATH**/ ?>