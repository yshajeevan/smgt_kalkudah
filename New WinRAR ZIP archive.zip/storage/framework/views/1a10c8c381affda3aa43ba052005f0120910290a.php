<div id="messages">
    <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-cogs fa-fw"></i>
        <!-- Counter - Messages -->
        <?php if(count(Helper::pendingprocess())>10): ?>
            <span data-count="10" class="badge badge-danger badge-counter">10+</span>
        <?php else: ?> 
            <span data-count="<?php echo e(count(Helper::pendingprocess())); ?>" class="badge badge-danger badge-counter"><?php echo e(count(Helper::pendingprocess())); ?></span>
        <?php endif; ?>
    </a>
    <!-- Dropdown - Messages -->
    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
        <h6 class="dropdown-header">
        Pending Process
        </h6>
        <div id="message-items">
            <?php $__currentLoopData = Helper::pendingprocess(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('process.edit',$process->id)); ?>">
                    <div class="dropdown-list-image mr-3">
                        <?php if($process->employee->photo): ?>
                        <img class="rounded-circle" src="<?php echo e($process->employee->photo); ?>" alt="profile">
                        <?php else: ?> 
                        <img class="rounded-circle" src="<?php echo e(asset('backend/img/avatar.png')); ?>" alt="default img">
                        <?php endif; ?>
                        
                    </div>
                    <div class="font-weight-bold">
                        <div class="text-truncate"><?php echo e($process->employee->namewithinitial); ?></div>
                        <div class="small text-gray-500"><?php echo e($process->service->service); ?> | Process ID: <?php echo e($process->id); ?></div>
                    </div>
                </a>
                <?php if($loop->index+1==10): ?> 
                  <?php 
                    break;
                  ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="dropdown-item text-center small text-gray-500" href="<?php echo e(route('process.index',1)); ?>">Read More Pending Processes</a>
    </div>
</div>


<?php /**PATH D:\VS Projects\SMGT\resources\views/processnotification/show.blade.php ENDPATH**/ ?>