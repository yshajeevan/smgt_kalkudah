                <table id="coursetable">
                    <thead>
                        <tr>
                            <th style="width:40%;">Couse Name</th>
                            <th style="width:40%;">Institution</th>
                            <th style="width:20%;">Duration(Months)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="qualifications[<?php echo e($loop->index); ?>][id]" value="<?php echo e($item->id); ?>">
                            <tr id="rowdata_<?php echo e($item->id); ?>">
                                <td>
                                    <input list="course_name" class="form-control form-control-sm" name="qualifications[<?php echo e($loop->index); ?>][course_name]" value="<?php echo e($item->course_name); ?>" readonly/>
                                    <datalist id="course_name">
                                        <?php $__currentLoopData = $qualifData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($qdata->course_name); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </td>
                                <td><input list="instituion" class="form-control form-control-sm" name="qualifications[<?php echo e($loop->index); ?>][institution]" value="<?php echo e($item->institution); ?>" readonly/>
                                    <datalist id="instituion">
                                        <?php $__currentLoopData = $instituteData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($idata->institution); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </datalist>
                                </td>
                                <td><input type="text" class="form-control form-control-sm" name="qualifications[<?php echo e($loop->index); ?>][duration]" value="<?php echo e($item->duration); ?>" readonly/></td>
                                <td><button data-id="removedata_<?php echo e($item->id); ?>" class="btn removedata btn-danger btn-sm" style="display:none;"><i class="fa fa-trash"></i></button>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class='element' id='div_1'></div>
                    </tbody>
                </table><?php /**PATH E:\VS Projects\SMGT\resources\views/human_resource/partials/qualifications.blade.php ENDPATH**/ ?>