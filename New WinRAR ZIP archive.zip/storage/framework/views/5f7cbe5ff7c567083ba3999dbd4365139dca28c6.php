<table id="subjecttable">
    <thead>
        <tr>
            <th style="width:40%;">Teaching Subject</th>
            <th style="width:40%;">Periods (Per week)</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $teachsubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="hidden" name="teachsubjects[<?php echo e($loop->index); ?>][id]" value="<?php echo e($item->id); ?>">
        <tr id="rowdata1_<?php echo e($item->id); ?>">
            <td>
                <select name="teachsubjects[<?php echo e($loop->index); ?>][teachsubject_id]" class="form-control selectdrp" disabled >
                    <option disabled selected value> -- Select Teaching Subject -- </option>
                    <?php $__currentLoopData = $cadresubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadresub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cadresub->id); ?>" <?php echo e((isset($item) && $item->cadresubject_id == $cadresub->id)  ? 'selected' : ''); ?>><?php echo e($cadresub->cadre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select> 
            </td>
            <td><input type="text" class="form-control form-control-sm" name="teachsubjects[<?php echo e($loop->index); ?>][periods]" value="<?php echo e($item->periods); ?>" readonly/></td>
            <td><button data-id="removedata1_<?php echo e($item->id); ?>" class="btn removedata1 btn-danger btn-sm" style="display:none;"><i class="fa fa-trash"></i></button></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class='element1' id='div_1'></div>
    </tbody>
</table><?php /**PATH E:\VS Projects\SMGT\resources\views/human_resource/partials/teachsubjects.blade.php ENDPATH**/ ?>