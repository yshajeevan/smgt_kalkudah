<!-- <?php
    $template = Auth::user()->hasAnyRole(['Sch_Admin']) ? 'layouts.school.master' : 'layouts.master';
?> -->



<?php $__env->startSection('main-content'); ?>
<div class="row">
    <div class="col-12">
        <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-3">
        <div class="card lookup">
            <div class="card">
                <div class="image">
                    <form action="<?php echo e(isset($employee) ? route('employee.photoupdate',$employee->id) : ''); ?>" name="profile_photo" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="profile-pic-div">
                        <?php if(!empty($employee->photo)): ?>
                        <img class="card-img-top img-fluid roundend-circle mt-4" style="border-radius:50%;height:120px;width:120px;margin:auto;" src="<?php echo e(asset('vfiles/profileimg/').'/'.$employee->photo); ?>" id="photo">
                        <?php else: ?> 
                        <img class="card-img-top img-fluid roundend-circle mt-4" style="border-radius:50%;height:120px;width:120px;margin:auto;" src="<?php echo e(asset('backend/img/avatar.png')); ?>" id="photo">
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?>
                        <input type="file" id="filepro" name="file" required>
                        <label for="filepro" id="uploadBtn">Choose Photo</label>
                        <?php endif; ?>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?>
                        <button style="display:none" class="btn" id="proimgupdate"><i class='fas fa-check-circle' style='color: green'></i></button>
                    <?php endif; ?>
                    </div>
                    <?php if(!empty($employee->id)): ?>
                    <div class="card-body mt-4 ml-2">
                      <h5 class="card-title text-left"><small><i class="fas fa-user"></i> <?php echo e($employee->title.".".$employee->initial.".".$employee->surname); ?></small></h5>
                      <p class="card-text text-left"><small><i class="fas fa-home"></i> <?php echo e($employee->peraddress); ?></small></p>
                      <!--<p class="card-text text-left"><small><i class="fas fa-phone"></i> <?php echo e($employee->mobile); ?></small></p>-->
                      <a class="card-text text-left" href="tel:+94<?php echo e(isset($employee->mobile) ? $employee->mobile : 'N/A'); ?>"><i class="fa fa-phone"></i><small><?php echo e($employee->mobile); ?></small></a></br>
                      <a class="card-text text-left" href="https://api.whatsapp.com/send?phone=94<?php echo e(isset($employee->whatsapp) ? $employee->whatsapp : 'N/A'); ?>"><i class="fab fa-whatsapp-square"></i><small><?php echo e($employee->whatsapp); ?></small></a></br>
                      <a class="card-text text-left" href="mailto: <?php echo e(isset($employee->email) ? $employee->email : 'N/A'); ?>"><i class="fa fa-envelope"></i><small><?php echo e($employee->email); ?></small></a>
                    </div>
                     <?php endif; ?>
                </form>
            </div>
            <div class="card-header">
                Go to section
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><a href="#" class="nav-jump" data-target="#bioinfo">Biological Info</a></li>
                <li class="list-group-item"><a href="#" class="nav-jump" data-target="#geoinfo">Geographical Info</a></li>
                <li class="list-group-item"><a href="#" class="nav-jump" data-target="#serviceinfo">Service Info</a></li>
                <li class="list-group-item"><a href="#" class="nav-jump" data-target="#qualifinfo">Qualifications</a></li>
                <li class="list-group-item"><a href="#" class="nav-jump" data-target="#subjectinfo">Subjects</a></li>
                <li class="list-group-item"><a href="#" class="nav-jump" data-target="#statusinfo">Current Status</a></li>
            </ul>
        </div>
    </div>
    <div class="col-lg-9 view" id="form">
        <?php if(Auth::user()->hasRole('Sch_Admin')): ?>
            <form id="employee_form" method="POST" action="<?php echo e(route('dummyemployee.store',$employee->id)); ?>" accept-charset="UTF-8" enctype="multipart/form-data">
        <?php else: ?>
            <form id="employee_form" method="POST" action="<?php echo e(isset($employee) ? route('employee.update',$employee->id) : route('employee.store')); ?>" accept-charset="UTF-8" enctype="multipart/form-data">
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <fieldset>
        <div class="form-card">
        <div class="card bioinfo" id="bioinfo">
            <div class="card-header">
                <b> <i class="fas fa-file"></i><span style="font-size: 13px"> Biological Information </span> </b><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button type="button" class="editbtn" id="edit"><i class="fas fa-edit"></i></button><?php endif; ?>
            </div>
            <div class="card-body">
                <?php if(isset($employee)): ?>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="id" class="control-label">Emp ID</label>
                    </div>    
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" id="id" value="<?php echo e(old('id', isset($employee) ? $employee->id : '')); ?>" disabled>
                    </div>
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Pay.No</label>
                    </div>
                    <div class="form-col-10">        
                        <input type="text" class="form-control form-control-sm" name="empno" id="empno" value="<?php echo e(old('empno', isset($employee) ? $employee->empno : '')); ?>" required readonly>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">NIC</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm float" name="nic" id="nic" value="<?php echo e(old('nic', isset($employee) ? $employee->nic : '')); ?>" required readonly>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id:''); ?>" data-title="SMGT-vFiles" data-group="a" href="<?php echo e(isset($employee->virtualfile->nicf) ? asset('/vfiles/' ).'/'.$employee->virtualfile->nicf : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->nicf) ? asset('/vfiles/' ).'/'.$employee->virtualfile->nicf : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button type="button" class="imgedit" id="nicf" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i></button><?php endif; ?>
                        
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id:''); ?>" data-title="SMGT-vFiles" data-group="a" href="<?php echo e(isset($employee->virtualfile->nicb) ? asset('/vfiles/' ).'/'.$employee->virtualfile->nicb : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->nicb) ? asset('/vfiles/' ).'/'.$employee->virtualfile->nicb : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="nicb" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i></button><?php endif; ?>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->nic != $employee->nic): ?> <span class="dummy-value"><?php echo e($employee->empdummy->nic); ?> </span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">NIC New (If)</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="nicnew" id="nicnew" value="<?php echo e(old('nicnew', isset($employee) ? $employee->nicnew : '')); ?>" required readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->nicnew != $employee->nicnew): ?> <span class="dummy-value"><?php echo e($employee->empdummy->nicnew); ?> <input type="hidden" name="dummy_nicnew" value="<?php echo e($employee->empdummy->nicnew); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Title</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="title" id="title" value="<?php echo e(old('title', isset($employee) ? $employee->title : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->title != $employee->title): ?> <span class="dummy-value"><?php echo e($employee->empdummy->title); ?> <input type="hidden" name="dummy_title" value="<?php echo e($employee->empdummy->title); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="initial" class="control-label">Initial</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="initial" id="initial" value="<?php echo e(old('initial', isset($employee) ? $employee->initial : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->initial != $employee->initial): ?> <span class="dummy-value"><?php echo e($employee->empdummy->initial); ?> <input type="hidden" name="dummy_initial" value="<?php echo e($employee->empdummy->initial); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="surname" class="control-label">Surname</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="surname" id="surname" value="<?php echo e(old('surname', isset($employee) ? $employee->surname : '')); ?>" required readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->surname != $employee->surname): ?> <span class="dummy-value"><?php echo e($employee->empdummy->surname); ?> <input type="hidden" name="dummy_surname" value="<?php echo e($employee->empdummy->surname); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>    
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Name in Full</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="fullname" id="fullname" value="<?php echo e(old('fullname', isset($employee) ? $employee->fullname : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->fullname != $employee->fullname): ?> <span class="dummy-value"><?php echo e($employee->empdummy->fullname); ?> <input type="hidden" name="dummy_fullname" value="<?php echo e($employee->empdummy->fullname); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">DOB</label>
                    </div>
                    <div class="form-col-10">
                        <input type="date" class="form-control form-control-sm float" name="dob" id="dob" value="<?php echo e(old('dob', isset($employee) ? $employee->dob : '')); ?>" readonly>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->birthcert) ? asset('/vfiles/' ).'/'.$employee->virtualfile->birthcert : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->birthcert) ? asset('/vfiles/' ).'/'.$employee->virtualfile->birthcert : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="birthcert" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i></button><?php endif; ?>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->dob != $employee->dob): ?> <span class="dummy-value"><?php echo e($employee->empdummy->dob); ?> <input type="hidden" name="dummy_dob" value="<?php echo e($employee->empdummy->dob); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Gender</label>
                    </div>
                    <div class="form-col-10">
                        <select name="gender" id="gender" class="form-control form-control-sm" required disabled>
                            <option value="" <?php if(isset($employee) && $employee->gender==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Gender--</option>
                            <option value="Male" <?php if(isset($employee) && $employee->gender=="Male"): ?><?php echo e("selected"); ?> <?php endif; ?> >Male</option>
                            <option value="Female" <?php if(isset($employee) && $employee->gender=="Female"): ?><?php echo e("selected"); ?> <?php endif; ?> >Female</option>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->gender != $employee->gender): ?> <span class="dummy-value"><?php echo e($employee->empdummy->gender); ?> <input type="hidden" name="dummy_gender" value="<?php echo e($employee->empdummy->gender); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Civil Status</label>
                    </div>
                    <div class="form-col-10">
                        <select name="civilstatus" id="civilstatus" class="form-control form-control-sm" disabled>
                            <option value="" <?php if(isset($employee) && $employee->civilstatus==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Civil Status--</option>
                            <option value="Married" <?php if(isset($employee) && $employee->civilstatus=="Married"): ?><?php echo e("selected"); ?> <?php endif; ?> >Married</option>
                            <option value="Single" <?php if(isset($employee) && $employee->civilstatus=="Single"): ?><?php echo e("selected"); ?> <?php endif; ?> >Single</option>
                            <option value="Widowed" <?php if(isset($employee) && $employee->civilstatus=="Widowed"): ?><?php echo e("selected"); ?> <?php endif; ?> >Widowed</option>
                            <option value="Not Specified" <?php if(isset($employee) && $employee->civilstatus=="Not Specified"): ?><?php echo e("selected"); ?> <?php endif; ?> >Not Specified</option>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->civilstatus != $employee->civilstatus): ?> <span class="dummy-value"><?php echo e($employee->empdummy->civilstatus); ?> <input type="hidden" name="dummy_civilstatus" value="<?php echo e($employee->empdummy->civilstatus); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Ethnicity</label>
                    </div>
                    <div class="form-col-10">
                        <select name="ethinicity" id="ethinicity" class="form-control form-control-sm" disabled>
                            <option value="" <?php if(isset($employee) && $employee->ethinicity==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Ethnicity--</option>
                            <option value="Tamil" <?php if(isset($employee) && $employee->ethinicity=="Tamil"): ?><?php echo e("selected"); ?> <?php endif; ?> >Tamil</option>
                            <option value="Muslim" <?php if(isset($employee) && $employee->ethinicity=="Muslim"): ?><?php echo e("selected"); ?> <?php endif; ?> >Muslim</option>
                            <option value="Sinhala" <?php if(isset($employee) && $employee->ethinicity=="Sinhala"): ?><?php echo e("selected"); ?> <?php endif; ?> >Sinhala</option>
                            <option value="Burger" <?php if(isset($employee) && $employee->ethinicity=="Burger"): ?><?php echo e("selected"); ?> <?php endif; ?> >Burger</option>
                            <option value="Others" <?php if(isset($employee) && $employee->ethinicity=="Others"): ?><?php echo e("selected"); ?> <?php endif; ?> >Others</option>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->ethinicity != $employee->ethinicity): ?> <span class="dummy-value"><?php echo e($employee->empdummy->ethinicity); ?> <input type="hidden" name="dummy_ethinicity" value="<?php echo e($employee->empdummy->ethinicity); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Religion</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="religion" id="religion" class="form-control form-control-sm" disabled>
                            <option value="" <?php if(isset($employee) && $employee->religion==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Religion--</option>
                            <option value="Hindu" <?php if(isset($employee) && $employee->religion=="Hindu"): ?><?php echo e("selected"); ?> <?php endif; ?> >Hindu</option>
                            <option value="Islam" <?php if(isset($employee) && $employee->religion=="Islam"): ?><?php echo e("selected"); ?> <?php endif; ?> >Islam</option>
                            <option value="RC" <?php if(isset($employee) && $employee->religion=="RC"): ?><?php echo e("selected"); ?> <?php endif; ?> >RC</option>
                            <option value="NRC" <?php if(isset($employee) && $employee->religion=="NRC"): ?><?php echo e("selected"); ?> <?php endif; ?> >NRC</option>
                            <option value="Buddhist" <?php if(isset($employee) && $employee->religion=="Buddhist"): ?><?php echo e("selected"); ?> <?php endif; ?> >Buddhist</option>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->religion != $employee->religion): ?> <span class="dummy-value"><?php echo e($employee->empdummy->religion); ?> <input type="hidden" name="dummy_religion" value="<?php echo e($employee->empdummy->religion); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
            </div>   
        </div>
        <!-- Fersonal info end & Geographical Information start-->
        <div class="card geoinfo" id="geoinfo">
            <div class="card-header">
                <b> <i class="fas fa-map"></i><span style="font-size: 13px"> Geographical Information</span> </b>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Permanant Address</label>
                    </div>
                    <div class="form-col-10">  
                        <input type="text" class="form-control form-control-sm" name="peraddress" id="peraddress" value="<?php echo e(old('peraddress', isset($employee) ? $employee->peraddress : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->peraddress != $employee->peraddress): ?> <span class="dummy-value"><?php echo e($employee->empdummy->peraddress); ?> <input type="hidden" name="dummy_peraddress" value="<?php echo e($employee->empdummy->peraddress); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div> 
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Temprory Address</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="tmpaddress" id="tmpaddress" value="<?php echo e(old('tmpaddress', isset($employee) ? $employee->tmpaddress : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->tmpaddress != $employee->tmpaddress): ?> <span class="dummy-value"><?php echo e($employee->empdummy->tmpaddress); ?> <input type="hidden" name="dummy_tmpaddress" value="<?php echo e($employee->empdummy->tmpaddress); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Residential DS</label>
                    </div>   
                    <div class="form-col-10"> 
                        <select name="dsdivision_id" id="dsdivision_id" class="form-control form-control-sm" disabled>
                            <option>--Select DS Division--</option>
                            <?php $__currentLoopData = $ds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ds->id); ?>" <?php echo e((isset($employee) && $employee->dsdivision_id == $ds->id)  ? 'selected' : ''); ?>><?php echo e($ds->ds); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->dsdivision_id != $employee->dsdivision_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->dsdivision->ds); ?> <input type="hidden" name="dummy_dsdivision_id" value="<?php echo e($employee->empdummy->dsdivision_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div> 
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Residential GN</label>
                    </div>
                    <div class="form-col-10">
                        <select name="gndivision_id" id="gndivision_id" class="form-control form-control-sm" disabled>
                            <option>-- Select GN Division --</option>
                            <?php $__currentLoopData = $gn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($gn->id); ?>" <?php echo e((isset($employee) && $employee->gndivision_id == $gn->id)  ? 'selected' : ''); ?>><?php echo e($gn->gn); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->gndivision_id != $employee->gndivision_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->gndivision->gn); ?> <input type="hidden" name="dummy_gndivision_id" value="<?php echo e($employee->empdummy->gndivision_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Residential Zone</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="zone_id" id="zone_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Education Zone--</option>
                            <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($zone->id); ?>" <?php echo e((isset($employee) && $employee->zone_id == $zone->id)  ? 'selected' : ''); ?>><?php echo e($zone->zone); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->zone_id != $employee->zone_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->zone->zone); ?> <input type="hidden" name="dummy_zone_id" value="<?php echo e($employee->empdummy->zone_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Transportaion Mode</label>
                    </div>
                    <div class="form-col-10">
                        <select name="transmode_id" id="transmode_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Transportation Mode--</option>
                            <?php $__currentLoopData = $transmodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($transmode->id); ?>" <?php echo e((isset($employee) && $employee->transmode_id == $transmode->id)  ? 'selected' : ''); ?>><?php echo e($transmode->tranmode); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->transmode_id != $employee->transmode_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->transmode->tranmode); ?> <input type="hidden" name="dummy_transmode_id" value="<?php echo e($employee->empdummy->transmode_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Distance to Resident</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="distores" id="distores" value="<?php echo e(old('distores', isset($employee) ? $employee->distores : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->distores != $employee->distores): ?> <span class="dummy-value"><?php echo e($employee->empdummy->distores); ?> <input type="hidden" name="dummy_distores" value="<?php echo e($employee->empdummy->distores); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <?php
                    function fullMask($val){
                        if (!$val) return '';
                        return str_repeat('*', mb_strlen($val));
                    }

                    $mobile = old('mobile', isset($employee) ? $employee->mobile : '');
                    $whatsapp = old('whatsapp', isset($employee) ? $employee->whatsapp : '');
                    $fixed = old('fixedphone', isset($employee) ? $employee->fixedphone : '');
                ?>

                <div class="form-group">
                    <div class="form-col-2"><label class="control-label">Mobile</label></div>
                    <div class="form-col-10" style="position:relative;">
                        <input type="text" class="form-control form-control-sm"
                            id="mobile" name="mobile"
                            value="<?php echo e(fullMask($mobile)); ?>" readonly
                            data-original="<?php echo e(e($mobile)); ?>">
                        <i class="fas fa-eye toggle-visibility" data-target="mobile"
                        style="cursor:pointer; position:absolute; right:10px; top:8px;"></i>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-col-2"><label class="control-label">Whatsapp</label></div>
                    <div class="form-col-10" style="position:relative;">
                        <input type="text" class="form-control form-control-sm"
                            id="whatsapp" name="whatsapp"
                            value="<?php echo e(fullMask($whatsapp)); ?>" readonly
                            data-original="<?php echo e(e($whatsapp)); ?>">
                        <i class="fas fa-eye toggle-visibility" data-target="whatsapp"
                        style="cursor:pointer; position:absolute; right:10px; top:8px;"></i>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-col-2"><label class="control-label">Fixed Phone</label></div>
                    <div class="form-col-10"
                     style="position:relative;">
                        <input type="text" class="form-control form-control-sm"
                            id="fixedphone" name="fixedphone"
                            value="<?php echo e(fullMask($fixed)); ?>" readonly
                            data-original="<?php echo e(e($fixed)); ?>">
                        <i class="fas fa-eye toggle-visibility" data-target="fixedphone"
                        style="cursor:pointer; position:absolute; right:10px; top:8px;"></i>
                    </div>
                </div>

                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">eMail ID</label>
                    </div>  
                    <div class="form-col-2">  
                        <input type="text" class="form-control form-control-sm" name="email" id="email" value="<?php echo e(old('email', isset($employee) ? $employee->email : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->email != $employee->email): ?> <span class="dummy-value"><?php echo e($employee->empdummy->email); ?> <input type="hidden" name="dummy_email" value="<?php echo e($employee->empdummy->email); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Service Information start-->
        <div class="card serviceinfo" id="serviceinfo">
            <div class="card-header">
                <b> <i class="fas fa-map"></i><span style="font-size: 13px"> Service Information</span> </b>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Service</label>
                    </div>
                    <div class="form-col-10">
                        <select name="empservice_id" id="empservice_id" class="form-control form-control-sm float" disabled>
                            <option value="">--Select Service--</option>
                    		<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>" <?php echo e((isset($employee) && $employee->empservice_id == $service->id)  ? 'selected' : ''); ?>><?php echo e($service->service); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    	</select>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->firstappltr) ? asset('/vfiles/' ).'/'.$employee->virtualfile->firstappltr : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->firstappltr) ? asset('/vfiles/' ).'/'.$employee->virtualfile->firstappltr : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="firstappltr" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->empservice_id != $employee->empservice_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->empservice->service); ?> <input type="hidden" name="dummy_empservice_id" value="<?php echo e($employee->empdummy->empservice_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Grade</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="grade" id="grade" class="form-control form-control-sm float" disabled>
                            <option value="" <?php if(isset($employee) && $employee->grade==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Grade--</option>
                            <option value="3-II" <?php if(isset($employee) && $employee->grade=="3-II"): ?><?php echo e("selected"); ?> <?php endif; ?> >3-II</option>
                            <option value="3-IA" <?php if(isset($employee) && $employee->grade=="3-IA"): ?><?php echo e("selected"); ?> <?php endif; ?> >3-IA</option>
                            <option value="3-IB" <?php if(isset($employee) && $employee->grade=="3-IB"): ?><?php echo e("selected"); ?> <?php endif; ?> >3-IB</option>
                            <option value="3-IC" <?php if(isset($employee) && $employee->grade=="3-IC"): ?><?php echo e("selected"); ?> <?php endif; ?> >3-IC</option>
                            <option value="III" <?php if(isset($employee) && $employee->grade=="III"): ?><?php echo e("selected"); ?> <?php endif; ?> >III</option>
                            <option value="2-II" <?php if(isset($employee) && $employee->grade=="2-II"): ?><?php echo e("selected"); ?> <?php endif; ?> >2-II</option>
                            <option value="2-I" <?php if(isset($employee) && $employee->grade=="2-I"): ?><?php echo e("selected"); ?> <?php endif; ?> >2-I</option>
                            <option value="II" <?php if(isset($employee) && $employee->grade=="II"): ?><?php echo e("selected"); ?> <?php endif; ?> >II</option>
                            <option value="I" <?php if(isset($employee) && $employee->grade=="I"): ?><?php echo e("selected"); ?> <?php endif; ?> >I</option>
                    	</select>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->promoltr) ? asset('/vfiles/' ).'/'.$employee->virtualfile->promoltr : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->promoltr) ? asset('/vfiles/' ).'/'.$employee->virtualfile->promoltr : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="promoltr" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->grade != $employee->grade): ?> <span class="dummy-value"><?php echo e($employee->empdummy->grade); ?> <input type="hidden" name="dummy_grade" value="<?php echo e($employee->empdummy->grade); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Duty Assm.of First Appointment</label>
                    </div>
                    <div class="form-col-10">
                        <input type="date" class="form-control form-control-sm float" name="dtyasmfapp" id="dtyasmfapp" value="<?php echo e(old('dtyasmfapp', isset($employee) ? $employee->dtyasmfapp : '')); ?>" readonly>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->firstdtyassm) ? asset('/vfiles/' ).'/'.$employee->virtualfile->firstdtyassm : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->firstdtyassm) ? asset('/vfiles/' ).'/'.$employee->virtualfile->firstdtyassm : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="firstdtyassm" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->dtyasmfapp != $employee->dtyasmfapp): ?> <span class="dummy-value"><?php echo e($employee->empdummy->dtyasmfapp); ?> <input type="hidden" name="dummy_dtyasmfapp" value="<?php echo e($employee->empdummy->dtyasmfapp); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">App.Date in Pre.Service</label>
                    </div>
                    <div class="form-col-10">                
                        <input type="date" class="form-control form-control-sm float" name="dtyasmcser" id="dtyasmcser" value="<?php echo e(old('dtyasmcser', isset($employee) ? $employee->dtyasmcser : '')); ?>" readonly>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->appltrcserv) ? asset('/vfiles/' ).'/'.$employee->virtualfile->appltrcserv : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->appltrcserv) ? asset('/vfiles/' ).'/'.$employee->virtualfile->appltrcserv : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="appltrcserv" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->dtyasmcser != $employee->dtyasmcser): ?> <span class="dummy-value"><?php echo e($employee->empdummy->dtyasmcser); ?> <input type="hidden" name="dummy_dtyasmcser" value="<?php echo e($employee->empdummy->dtyasmcser); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Designation</label>
                    </div>
                    <div class="form-col-10">
                        <select name="designation_id" id="designation_id" class="form-control form-control-sm float" required disabled>
                            <option value="">--Select Designation--</option>
                    		<?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($designation->id); ?>" <?php echo e((isset($employee) && $employee->designation_id == $designation->id)  ? 'selected' : ''); ?>><?php echo e($designation->designation); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->designationltr) ? asset('/vfiles/' ).'/'.$employee->virtualfile->designationltr : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->designationltr) ? asset('/vfiles/' ).'/'.$employee->virtualfile->designationltr : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="designationltr" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->designation_id != $employee->designation_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->designation->designation); ?> <input type="hidden" name="dummy_designation_id" value="<?php echo e($employee->empdummy->designation_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Permanent Institute (as per paysheet)</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="institute_id" id="institute_id" class="form-control form-control-sm" required disabled>
                            <option value="">--Select Institution--</option>
                    		<?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($institute->id); ?>" <?php echo e((isset($employee) && $employee->institute_id == $institute->id)  ? 'selected' : ''); ?>><?php echo e($institute->institute); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->institute_id != $employee->institute_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->institute->institute); ?> <input type="hidden" name="dummy_institute_id" value="<?php echo e($employee->empdummy->institute_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Current Working Station (Attachment/temprory)</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="current_working_station" id="current_working_station" class="form-control form-control-sm" required disabled>
                            <option value="">--Select Institution--</option>
                    		<?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($institute->id); ?>" <?php echo e((isset($employee) && $employee->current_working_station == $institute->id)  ? 'selected' : ''); ?>><?php echo e($institute->institute); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->current_working_station != $employee->current_working_station): ?> <span class="dummy-value"><?php echo e($employee->empdummy->workingStation->institute); ?> <input type="text" name="dummy_current_working_station" value="<?php echo e($employee->empdummy->current_working_station); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Dty.Assm in Pre.Institute</label>
                    </div>
                    <div class="form-col-10">
                        <input type="date" class="form-control form-control-sm float" name="dtyasmprins" id="dtyasmprins" value="<?php echo e(old('dtyasmprins', isset($employee) ? $employee->dtyasmprins : '')); ?>" readonly>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->dtysssmprinst) ? asset('/vfiles/' ).'/'.$employee->virtualfile->dtysssmprinst : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->dtysssmprinst) ? asset('/vfiles/' ).'/'.$employee->virtualfile->dtysssmprinst : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="dtysssmprinst" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                </div>
                <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->dtyasmprins != $employee->dtyasmprins): ?> <span class="dummy-value"><?php echo e($employee->empdummy->dtyasmprins); ?> <input type="hidden" name="dummy_dtyasmprins" value="<?php echo e($employee->empdummy->dtyasmprins); ?>"/></span><?php endif; ?> <?php endif; ?>
            </div>
            <!--...............Service history.................-->
            <table>
                <thead>
                    <tr>
                        <th colspan="4" style="background-color:#FAF0E6; font-weight:bold; text-align: center;">Service History(Source:NEMIS)</th>
                    </tr>
                    <tr>
                        <th>Zone</th>
                        <th>Institute</th>
                        <th>Date From</th>
                        <th>Date To</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(isset($employee)): ?>
                    <?php if($employee->servicehistory->count() > 0): ?>
                        <?php $__currentLoopData = $employee->servicehistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($emp->zone); ?></td>
                            <td><?php echo e($emp->institute); ?></td>
                            <td><?php echo e($emp->date_from); ?></td>
                            <td><?php echo e($emp->date_to); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Qualification Information start-->
        <div class="card qualifinfo" id="qualifinfo">
            <div class="card-header">
                <b> <i class="fas fa-map"></i><span style="font-size: 13px"> Education/Professional Qualifications</span> </b>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Higher Edu.Qualification</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="highqualification_id" id="highqualification_id" class="form-control form-control-sm float" disabled>
                            <option value="">--Select Highest Qualification--</option>
                            <?php $__currentLoopData = $highqualifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highqualif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($highqualif->id); ?>" <?php echo e((isset($employee) && $employee->highqualification_id	== $highqualif->id)  ? 'selected' : ''); ?>><?php echo e($highqualif->qualif); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->hiqualif) ? asset('/vfiles/' ).'/'.$employee->virtualfile->hiqualif : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->hiqualif) ? asset('/vfiles/' ).'/'.$employee->virtualfile->hiqualif : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="hiqualif" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->highqualification_id != $employee->highqualification_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->highqualif->qualif); ?> <input type="hidden" name="dummy_highqualification_id" value="<?php echo e($employee->empdummy->highqualification_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">                
                    <div class="form-col-2">
                        <label for="" class="control-label">Name of 1st Degree</label>
                    </div>
                    <div class="form-col-10">
                        <select name="degree_id" id="degree_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Degree--</option>
                    		<?php $__currentLoopData = $degrees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degree): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($degree->id); ?>" <?php echo e((isset($employee) && $employee->degree_id == $degree->id)  ? 'selected' : ''); ?>><?php echo e($degree->degree); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->degree_id != $employee->degree_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->degree->degree); ?> <input type="hidden" name="dummy_degree_id" value="<?php echo e($employee->empdummy->degree_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group"> 
                    <div class="form-col-2">
                        <label for="" class="control-label">Degree Obtained from</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="deginstitute_id" id="deginstitute_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Institution of Degree Obtained--</option>
                            <?php $__currentLoopData = $eduinsts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eduinst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($eduinst->id); ?>" <?php echo e((isset($employee) && $employee->deginstitute_id == $eduinst->id)  ? 'selected' : ''); ?>><?php echo e($eduinst->eduinsti); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->deginstitute_id != $employee->deginstitute_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->deginstitute->eduinsti); ?> <input type="hidden" name="dummy_deginstitute_id" value="<?php echo e($employee->empdummy->deginstitute_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Degree Type</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="degtype" id="degtype" class="form-control form-control-sm" disabled>
                            <option value="" <?php if(isset($employee) && $employee->degtype==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Degree Type--</option>
                            <option value="Internal" <?php if(isset($employee) && $employee->degtype=="Internal"): ?><?php echo e("selected"); ?> <?php endif; ?> >Internal</option>
                            <option value="External" <?php if(isset($employee) && $employee->degtype=="External"): ?><?php echo e("selected"); ?> <?php endif; ?> >External</option>
                            <option value="Distance" <?php if(isset($employee) && $employee->degtype=="Distance"): ?><?php echo e("selected"); ?> <?php endif; ?> >Distance</option>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->degtype != $employee->degtype): ?> <span class="dummy-value"><?php echo e($employee->empdummy->degtype); ?> <input type="hidden" name="dummy_degtype" value="<?php echo e($employee->empdummy->degtype); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Degree Subject 1</label>
                    </div>
                    <div class="form-col-10">    
                        <select name="degsubject1_id" id="degsubject1_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Degree Subject 1--</option>
                            <?php $__currentLoopData = $degreesubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degreesub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($degreesub->id); ?>" <?php echo e((isset($employee) && $employee->degsubject1_id == $degreesub->id)  ? 'selected' : ''); ?>><?php echo e($degreesub->degreesub); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->degsubject1_id != $employee->degsubject1_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->degsubject1->degreesub); ?> <input type="hidden" name="dummy_degsubject1_id" value="<?php echo e($employee->empdummy->degsubject1_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Degree Subject 2</label>
                    </div>
                    <div class="form-col-10"> 
                        <select name="degsubject2_id" id="degsubject2_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Degree Subject 2--</option>
                    		<?php $__currentLoopData = $degreesubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degreesub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($degreesub->id); ?>" <?php echo e((isset($employee) && $employee->degsubject2_id == $degreesub->id)  ? 'selected' : ''); ?>><?php echo e($degreesub->degreesub); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->degsubject2_id != $employee->degsubject2_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->degsubject2->degreesub); ?> <input type="hidden" name="dummy_degsubject2_id" value="<?php echo e($employee->empdummy->degsubject2_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Degree Subject 3</label>
                    </div>
                    <div class="form-col-10">     
                        <select name="degsubject3_id" id="degsubject3_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Degree Subject 3--</option>
                    		<?php $__currentLoopData = $degreesubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $degreesub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($degreesub->id); ?>" <?php echo e((isset($employee) && $employee->degsubject3_id == $degreesub->id)  ? 'selected' : ''); ?>><?php echo e($degreesub->degreesub); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->degsubject3_id != $employee->degsubject3_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->degsubject3->degreesub); ?> <input type="hidden" name="dummy_degsubject3_id" value="<?php echo e($employee->empdummy->degsubject3_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <br>
                <!--............................................................Other Qualifications....................................................-->
                <?php if(!empty($employee->id)): ?>
                    <?php echo $__env->make('human_resource.partials.qualifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <!--.......................................Dynamic Qualification Area Start.............................................. -->
                <div class="button-container float-left" id="addqualifbtn" style="display:none">
                    <button type="button" class="btn btn-success btn-sm addcourse"><i class="fa fa-plus"></i> Add row</button>
                </div>
                <!--.......................................Dynamic Qualification Area Area End.............................................. -->
                
            </div>
        </div>
        <!-- Qualification Information end Subject Information Start-->
        <div class="card subjectinfo" id="subjectinfo">
            <div class="card-header">
                <b> <i class="fas fa-map"></i><span style="font-size: 13px"> Subject Informations</span> </b>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Appointment Subject</label>
                    </div>
                    <div class="form-col-10">     
                        <input type="text" class="form-control form-control-sm float" name="appsubject" id="appsubject" value="<?php echo e(old('appsubject', isset($employee) ? $employee->appsubject : '')); ?>" readonly>
                        <div class="image-set"><a data-gallery="photoviewer" id="<?php echo e(isset($employee->virtualfile->id) ? $employee->virtualfile->id : ''); ?>" data-title="SMGT-Scanned Documents" data-group="a" href="<?php echo e(isset($employee->virtualfile->appsub) ? asset('/vfiles/' ).'/'.$employee->virtualfile->appsub : asset('/vfiles/No_Image_Available.jpg')); ?>">
                        <img src="<?php echo e(isset($employee->virtualfile->appsub) ? asset('/vfiles/' ).'/'.$employee->virtualfile->appsub : asset('/vfiles/No_Image_Available.jpg')); ?>" class="img-fluid img-thumbnail" alt="">
                        </a></div><?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('employee-edit')): ?><button class="imgedit" type="button" id="appsub" data-toggle="modal" data-target="#imageupload"><i class="fas fa-edit"></i><?php endif; ?></button>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->appsubject != $employee->appsubject): ?> <span class="dummy-value"><?php echo e($employee->empdummy->appsubject); ?> <input type="hidden" name="dummy_appsubject" value="<?php echo e($employee->empdummy->appsubject); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Appointment Category</label>
                    </div>
                    <div class="form-col-10">     
                        <select name="appcategory_id" id="appcategory_id" class="form-control form-control-sm" disabled>
                            <option value="">--Select Appointment Category--</option>
                    		<?php $__currentLoopData = $appcats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($appcat->id); ?>" <?php echo e((isset($employee) && $employee->appcategory_id == $appcat->id)  ? 'selected' : ''); ?>><?php echo e($appcat->appcat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->appcategory_id != $employee->appcategory_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->appcategory->appcat); ?> <input type="hidden" name="dummy_appcategory_id" value="<?php echo e($employee->empdummy->appcategory_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Cadre Subject</label>
                    </div>
                    <div class="form-col-10">
                        <select name="cadresubject_id" id="cadresubject_id" class="form-control form-control-sm" disabled required>
                            <option value="">--Select cadre Subject--</option>
                            <?php $__currentLoopData = $cadresubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadresub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cadresub->id); ?>" <?php echo e((isset($employee) && $employee->cadresubject_id == $cadresub->id)  ? 'selected' : ''); ?>><?php echo e($cadresub->cadre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	</select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->cadresubject_id != $employee->cadresubject_id): ?> <span class="dummy-value"><?php echo e($employee->empdummy->cadresubject->cadre); ?> <input type="hidden" name="dummy_cadresubject_id" value="<?php echo e($employee->empdummy->cadresubject_id); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Trained Status</label>
                    </div>
                    <div class="form-col-10">
                        <select name="trained" id="trained" class="form-control form-control-sm" disabled>
                            <option value="" <?php if(isset($employee) && $employee->trained==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Trained Status--</option>
                            <option value="trained" <?php if(isset($employee) && $employee->trained=="trained"): ?><?php echo e("selected"); ?> <?php endif; ?> >Trained</option>
                            <option value="untrained" <?php if(isset($employee) && $employee->trained=="untrained"): ?><?php echo e("selected"); ?> <?php endif; ?> >Un-Trained</option>
                            <option value="undertraining" <?php if(isset($employee) && $employee->trained=="undertraining"): ?><?php echo e("selected"); ?> <?php endif; ?> >Under Training</option>
                    	</select>
                    </div>
                </div>
                <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->trained != $employee->trained): ?> <span class="dummy-value"><?php echo e($employee->empdummy->trained); ?> <input type="hidden" name="dummy_trained" value="<?php echo e($employee->empdummy->trained); ?>"/></span><?php endif; ?> <?php endif; ?>
                <br>
                <?php if(!empty($employee->id)): ?>
                    <?php echo $__env->make('human_resource.partials.teachsubjects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <!--.......................................Dynamic Teaching Subject Area Start.............................................. -->
                <div class="button-container float-left" id="subjectbtn" style="display:none">
                    <button type="button" class="btn btn-success btn-sm addsubject"><i class="fa fa-plus"></i> Add row</button>
                </div>
                <!--.......................................Dynamic Teaching Subject Area Area End.............................................. -->
            </div>
        </div>
        <!-- Subject Information end status information start-->
        <div class="card statusinfo" id="statusinfo">
            <div class="card-header">
                <b> <i class="fas fa-map"></i><span style="font-size: 13px"> Current Status</span> </b>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Status(Active/In-Active)</label>
                    </div>
                    <div class="form-col-10">     
                        <select name="status" id="status" class="form-control form-control-sm" required disabled>
                            <option value="" <?php if(isset($employee) && $employee->status==""): ?><?php echo e("selected"); ?> <?php endif; ?> >--Select Status--</option>
                            <option value="Active" <?php if(isset($employee) && $employee->status=="Active"): ?><?php echo e("selected"); ?> <?php endif; ?> >Active</option>
                            <option value="TrOut" <?php if(isset($employee) && $employee->status=="TrOut"): ?><?php echo e("selected"); ?> <?php endif; ?> >TrOut</option>
                            <option value="Inactive" <?php if(isset($employee) && $employee->status=="Inactive"): ?><?php echo e("selected"); ?> <?php endif; ?> >Inactive</option>
                            <option value="Pension" <?php if(isset($employee) && $employee->status=="Pension"): ?><?php echo e("selected"); ?> <?php endif; ?> >Pension</option>
                        </select>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->status != $employee->status): ?> <span class="dummy-value"><?php echo e($employee->empdummy->status); ?> <input type="hidden" name="dummy_status" value="<?php echo e($employee->empdummy->status); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Remarks</label>
                    </div>
                    <div class="form-col-10">     
                        <input type="text" class="form-control form-control-sm" name="remark" id="remark" value="<?php echo e(old('remark', isset($employee) ? $employee->remark : '')); ?>" readonly>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->remark != $employee->remark): ?> <span class="dummy-value"><?php echo e($employee->empdummy->remark); ?> <input type="hidden" name="dummy_remark" value="<?php echo e($employee->empdummy->remark); ?>"/></span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Created on</label>
                    </div>
                    <div class="form-col-10">     
                        <input type="text" class="form-control form-control-sm" name="created_at" id="created_at" value="<?php echo e(old('created_at', isset($employee) ? $employee->created_at : '')); ?>" readonly disabled>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Last Modification Date & Time</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" name="updated_at" id="updated_at" value="<?php echo e(old('updated_at', isset($employee) ? $employee->updated_at : '')); ?>" readonly disabled>
                    </div>
                    <?php if(!empty($employee) && !empty($employee->empdummy)): ?> <?php if($employee->empdummy->updated_at != $employee->updated_at): ?> <span class="dummy-value"><?php echo e($employee->empdummy->updated_at); ?> </span><?php endif; ?> <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-col-2">
                        <label for="" class="control-label">Designation Category</label>
                    </div>
                    <div class="form-col-10">
                        <input type="text" class="form-control form-control-sm" id="desigcatg" name="desigcatg" value="<?php echo e(isset($employee) ? $employee->designation->catg : ''); ?>" required readonly>
                    </div>
                </div>
            </div>
        </div>
        <div class="card save">
            <div class="card-header">
                <!-- Certify checkbox - place this right above the submitdiv (always visible) -->
                <div class="form-group" id="certifyDiv" style="margin-bottom:8px;">
                    <div style="display:inline-block;vertical-align:middle;">
                        <label class="control-label" for="certifyChk"> </label>
                    </div>
                    <div class="form-col-10" style="display:inline-block;vertical-align:middle;">
                        <input type="checkbox" id="certifyChk" disabled />
                        <label for="certifyChk" style="margin-left:6px; font-weight:600;">I certify that above detailed are correct.</label>
                    </div>
                </div>
            </div>
            <div class="card-body">
                 <div class="form-group" align="center" id="submitdiv" style="display:none">
                    <button type="button" id="saveBtn" style="margin-left:15px;" class="btn btn-warning">
                        <?php echo e(isset($employee) ? 'Update' : 'Add'); ?>

                    </button>
                </div>
            </div>
        </div>
        </div> 
        </fieldset>
    </form>
</div>

<!-- Modal image upload Form Start -->
<div class="modal fade" id="imageupload" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload vFiles</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="<?php echo e(isset($employee->virtualfile->employee_id) ? route('vfile.update',$employee->id) : route('vfile.store')); ?>" name="addform" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>  
        <div class="modal-body">
                <img class="img-model" id="vphoto">
                <input type="file" id="files" name="file" required>
                <input type="hidden" id="curfield" name="curfield">
            </div>
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" id="imgupload"  value="<?php echo e(isset($employee->virtualfile->employee_id) ? 'Update' : 'Add'); ?>">
            </div>
        </form>
    </div>
  </div>
</div>

<?php echo $__env->make('human_resource.partials._dummy_update_modal', ['employee' => $employee, 'employeeDummy' => $employeeDummy], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('/css/photoviewer.css')); ?>" rel="stylesheet" />
<style>
.serviceinfo table, .serviceinfo table th, .serviceinfo table td {
  border: 1px solid #DCDCDC;
  border-collapse: collapse;
  font-size: 13px;
}

@media  only screen and (min-width: 768px) {
    .dummy-value{
        margin-left: 245px;
        margin-top: 10px;
    }
}
@media  only screen and (max-width: 768px) {
    .dummy-value{
        margin-left: 20px;
    }
}
.dummy-value{
    color: red;
    font-weight: bold;
}
.image{
        background:url('<?php echo e(asset('backend/img/background.jpg')); ?>');
        height:150px;
        background-position:center;
        background-attachment:cover;
        position: relative;
    }
    .image img{
        position: absolute;
        top:40%;
        left:35%;
        margin-top:30%;
    }
    i{
        font-size: 14px;
        padding-right:8px;
    }
.img-model{
    height:200px;
    width:auto;
}

#photo{
    height: 100%;
    width: 100%;
}

#filepro{
    display: none;
}

#uploadBtn{
    height: 40px;
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    text-align: center;
    background: rgba(0, 0, 0, 0.7);
    color: wheat;
    line-height: 30px;
    font-family: sans-serif;
    font-size: 15px;
    cursor: pointer;
    display: none;
}

@media  only screen and (min-width: 600px) {
    .lookup{
        position: fixed !important; 
        width:340px !important;
    }
}

.form-group {
  display: flex;
  flex-flow: row wrap;
  margin: 0 -1rem 1rem -1rem;
}

[class*="form-col"] {
  flex: 0 1 100%;
  padding: 0 1rem;
}

@media (min-width: 576px) {
  .form-col-2 {
    flex: 0 0 20%;
    max-width: 20%;
    height: 20px;
  }
  
  .form-col-10 {
    flex: 0 0 80%;
    max-width: 80%;
    height: 20px;
  }
  
}

.editbtn {
  background-color: transparent;
  border: none;
  color: green !important;
  font-size: 20px !important;
  cursor: pointer;
  float: right;
}
.imgedit {
  background-color: transparent;
  border: none;
  color: green !important;
  font-size: 15px !important;
  cursor: pointer;
  float: left;
}
.image-set{
   float:left !important;
}
.view input {
  border:1;
  background:0 !important;
  outline:none !important;
  border-color: #ffe6e6;
}
.view select {
  border:1;
  background:0 !important;
  outline:none !important;
  appearance: none;
  border-color: #ffe6e6;

}
.control-label{
    font-size:14px !important;
    font-weight: 500;
}
.form-group {
  padding:2px;
}
.b-image {
    float:left;
    width:20% !important;
}
.float {
    float:left;
    width:250px !important;
}
.img-thumbnail{
    height: 30px !important;
    width:auto !important;
    border-radius: 0rem !important;
    padding: 0 !important;
}

.photoviewer-modal {
      background-color: transparent;
      border: none;
      border-radius: 0;
      box-shadow: 0 0 6px 2px rgba(0, 0, 0, .3);
    }

    .photoviewer-header .photoviewer-toolbar {
      background-color: rgba(0, 0, 0, .5);
    }

    .photoviewer-stage {
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
      background-color: rgba(0, 0, 0, .85);
      border: none;
    }

    .photoviewer-footer .photoviewer-toolbar {
      background-color: rgba(0, 0, 0, .5);
      border-top-left-radius: 5px;
      border-top-right-radius: 5px;
    }

    .photoviewer-header,
    .photoviewer-footer {
      border-radius: 0;
      pointer-events: none;
    }

    .photoviewer-title {
      color: #ccc;
    }

    .photoviewer-button {
      color: #ccc;
      pointer-events: auto;
    }

    .photoviewer-header .photoviewer-button:hover,
    .photoviewer-footer .photoviewer-button:hover {
      color: white;
    }
    
    /*Ajax loader*/
    .overlay{
    display: none;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 999;
    background: rgba(255,255,255,0.8) url("/images/loader.gif") center no-repeat;
    }
    /* Turn off scrollbar when body element has the loading class */
    body.loading{
        overflow: hidden;   
    }
    /* Make spinner image visible when body element has the loading class */
    body.loading .overlay{
        display: block;
    }

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/js/photoviewer.js')); ?>"></script>
<script>
// Add remove loading class on body element based on Ajax request status
$(document).on({
    ajaxStart: function(){
        $("body").addClass("loading"); 
    },
    ajaxStop: function(){ 
        $("body").removeClass("loading"); 
    }    
});

// Replace your existing nav-jump handler with this simple robust one
document.addEventListener('DOMContentLoaded', function() {
  const OFFSET = 12; // adjust if you have fixed header
  document.querySelectorAll('.nav-jump').forEach(function(link) {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const targetSel = this.getAttribute('data-target');
      if (!targetSel) return console.warn('no data-target on', this);
      const target = document.querySelector(targetSel);
      if (!target) return console.warn('target not found', targetSel);

      // If the target is inside a scrollable ancestor (like a modal .modal-body), scroll that container.
      function scrollableAncestor(el) {
        let p = el.parentElement;
        while (p && p !== document.body) {
          const style = getComputedStyle(p);
          const overflowY = style.overflowY;
          if ((overflowY === 'auto' || overflowY === 'scroll') && p.scrollHeight > p.clientHeight) return p;
          p = p.parentElement;
        }
        // fallback to document scrollingElement
        return document.scrollingElement || document.documentElement;
      }

      const container = scrollableAncestor(target);

      if (container === (document.scrollingElement || document.documentElement)) {
        // page-level scroll: use scrollIntoView then adjust for OFFSET
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // small adjustment after scroll (works cross-browser)
        window.setTimeout(function() {
          window.scrollBy({ top: -OFFSET, left: 0, behavior: 'smooth' });
        }, 60);
      } else {
        // container-level scroll
        // compute target top relative to container
        const containerRect = container.getBoundingClientRect();
        const targetRect = target.getBoundingClientRect();
        const currentScroll = container.scrollTop;
        const relativeTop = (targetRect.top - containerRect.top) + currentScroll - OFFSET;
        // animate with requestAnimationFrame
        const start = container.scrollTop;
        const change = relativeTop - start;
        const duration = 400;
        let startTime = null;
        function animateScroll(time){
          if (!startTime) startTime = time;
          const t = Math.min(1, (time - startTime) / duration);
          // easeInOutQuad
          const eased = t < 0.5 ? 2*t*t : -1 + (4 - 2*t)*t;
          container.scrollTop = Math.round(start + change * eased);
          if (t < 1) requestAnimationFrame(animateScroll);
        }
        requestAnimationFrame(animateScroll);
      }

      // debug log
      console.log('nav-jump clicked ->', targetSel, 'container:', container.tagName);
    });
  });
});


//fetch image in model 
$('.imgedit').click(function () {
    var name = $(this).attr("id");
    $('#curfield').val($(this).attr("id"));
    if(name == 'nicf'){
        var file = <?php echo json_encode(isset($employee->virtualfile->nicf) ? $employee->virtualfile->nicf : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'nicb') {
         file = <?php echo json_encode(isset($employee->virtualfile->nicb) ? $employee->virtualfile->nicb : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'birthcert') {
         file = <?php echo json_encode(isset($employee->virtualfile->birthcert) ? $employee->virtualfile->birthcert : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'firstappltr') {
         file = <?php echo json_encode(isset($employee->virtualfile->firstappltr) ? $employee->virtualfile->firstappltr : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'promoltr') {
         file = <?php echo json_encode(isset($employee->virtualfile->promoltr) ? $employee->virtualfile->promoltr : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'firstdtyassm') {
         file = <?php echo json_encode(isset($employee->virtualfile->firstdtyassm) ? $employee->virtualfile->firstdtyassm : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'appltrcserv') {
         file = <?php echo json_encode(isset($employee->virtualfile->appltrcserv) ? $employee->virtualfile->appltrcserv : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'designationltr') {
         file = <?php echo json_encode(isset($employee->virtualfile->designationltr) ? $employee->virtualfile->designationltr : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'dtysssmprinst') {
         file = <?php echo json_encode(isset($employee->virtualfile->dtysssmprinst) ? $employee->virtualfile->dtysssmprinst : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'hiqualif') {
         file = <?php echo json_encode(isset($employee->virtualfile->hiqualif) ? $employee->virtualfile->hiqualif : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    } else if(name == 'appsub') {
         file = <?php echo json_encode(isset($employee->virtualfile->appsub) ? $employee->virtualfile->appsub : 'No_Image_Available.jpg', JSON_HEX_TAG); ?>;
    }
    
    var source = '<?php echo asset("/vfiles/"); ?>/' + file;
    $('.img-model').attr('src',source);
});

// Mask the mobile number and whatsapp nuber
document.addEventListener('click', function(e){
    if (!e.target.classList.contains('toggle-visibility')) return;

    var icon = e.target;
    var targetId = icon.getAttribute('data-target');
    var input = document.getElementById(targetId);
    var original = input.getAttribute('data-original') || '';

    if (icon.classList.contains('showing')) {
        // hide again - full mask
        input.value = '*'.repeat(original.length);
        icon.classList.remove('fa-eye-slash', 'showing');
        icon.classList.add('fa-eye');
    } else {
        // show full
        input.value = original;
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash', 'showing');
    }
});



//Employee photo upload
const imgDiv = document.querySelector('.profile-pic-div');
const img = document.querySelector('#photo');
const file = document.querySelector('#filepro');
const uploadBtn = document.querySelector('#uploadBtn');

imgDiv.addEventListener('mouseenter', function(){
    uploadBtn.style.display = "block";
});


imgDiv.addEventListener('mouseleave', function(){
    uploadBtn.style.display = "none";
});


file.addEventListener('change', function(){
    const choosedFile = this.files[0];
    if (choosedFile) {
        const reader = new FileReader(); //FileReader is a predefined function of JS
        reader.addEventListener('load', function(){
            img.setAttribute('src', reader.result);
        });
        reader.readAsDataURL(choosedFile);
    }
    
   var t = document.getElementById("proimgupdate");
      if (t.style.display === "none") {
        t.style.display = "block";
      }
});

$('#files').click(function () {
    const imgs = document.querySelector('#vphoto');
    const files = document.querySelector('#files');
    files.addEventListener('change', function(){
        const choosedFile = this.files[0];
        if (choosedFile) {
            const readers = new FileReader(); //FileReader is a predefined function of JS
            readers.addEventListener('load', function(){
                imgs.setAttribute('src', readers.result);
            });
            readers.readAsDataURL(choosedFile);
        }
    });
});

//Model photo viewer
$('[data-gallery=photoviewer]').click(function (e) {
e.preventDefault();

var items = [],
  options = {
    index: $(this).index(),
  };

  items.push({
    src: $(this).attr('href'),
    title: $(this).attr('data-title')
  });
new PhotoViewer(items, options);
});


//Goto section href functions
$(document).ready(function () {
  
    $('#dsdivision_id').change(function () {
             var id = $(this).val();

             $('#gndivision_id').find('option').not(':first').remove();

             $.ajax({
                url:'/gndetails/'+id,
                type:'get',
                dataType:'json',
                success:function (response) {
                    var len = 0;
                    if (response.data != null) {
                        len = response.data.length;
                    }

                    if (len>0) {
                        for (var i = 0; i<len; i++) {
                             var id = response.data[i].id;
                             var gn = response.data[i].gn;

                             var option = "<option value='"+id+"'>"+gn+"</option>"; 

                             $("#gndivision_id").append(option);
                        }
                    }
                }
             })
           });
           
           $('#gndivision_id').change(function () {
               getdistrance();
           });
           
           $('#institute_id').change(function () {
               getdistrance();
           });
           
            function getdistrance(){
                var gnid = $('#gndivision_id').val();
               var insid = $('#institute_id').val();
               $.ajax({
                    url: "<?php echo e(url('/distrance')); ?>",
                    method: 'get',
                      data: {
                        gnid:gnid, 
                        insid:insid
                        },
                        success: function(response){
                          $("#distores").val(response.distance);
     
                  }
                });
            }
            
            $('#designation_id').change(function (){
                var id = $(this).val();
                $.ajax({
                    url:'/desigcatg/'+id,
                    type:'get',
                    dataType:'json',
                    success: function(response){
                        $("#desigcatg").val(response.catg);
                        console.log(response.catg);
                    },
                    error: function(response){
                        alert("Error")
                    }
             });
           });
    //..........................................................Adding a Cource.........................................................       
    $(".addcourse").click(function(e){
        e.preventDefault();
         // Finding total number of elements added
        var total_element = $(".element").length;
        // last <div> with element class id
        var lastid = $(".element:last").attr("id");
        var split_id = lastid.split("_");
        var nextindex = Number(split_id[1]) + 1;

 
            // Adding new div container after last occurance of element class
            $(".element:last").after("<div class='element' id='div_"+ nextindex +"'></div>");

            // Adding element to <table>
            var html="";
            html += "<tr id='row_"+ nextindex +"'>";
            html += "<td>";
            html += "<input class='form-control form-control-sm' list='courses' name='course_name[]' id='course_name"+ nextindex +"' autocomplete='off' required>";
            html += "<datalist id='courses'>"
            html += "<option selected>--Choose or enter Course--</option>"
            html += "</datalist>";
            html += "</td>";
            html += "<td>";
            html += "<input list='institutions' class='form-control form-control-sm' name='institution[]' id='institution"+ nextindex +"' autocomplete='off' required>";
            html += "<datalist id='institutions'>"
            html += "<option selected>--Choose or enter Institution--</option>"
            html += "</datalist>";
            html += "</td>";
            html += "<td>";
            html += "<input type='text' class='form-control form-control-sm' id='duration"+ nextindex +"' name='duration[]' required>";
            html += "</td>";
            html += "<td>"
            html += "<button type='button' id='remove_" + nextindex + "' class='btn remove btn-danger btn-sm'><i class='fa fa-trash'></i></button>";
            html += "</td>";
            html += "</tr>";
            
            $("#coursetable").find('tbody').append(html);
        
             //Append to parallel class
            var len= 0;
            var qualifData = <?php echo isset($qualifData) ? $qualifData : 'null'; ?>;
            len = qualifData.length;
            console.log(len);
            if(len > 0){
               // Read data and create <option >
               for(var i=0; i<len; i++){
                var course_name = qualifData[i].course_name;
                var option1 = "<option value="+course_name+">";

                $("#courses"+ nextindex +"").append(option1);  
               }
            }
    });
    
    // Remove element
    $('.form-card').on('click','.remove',function(e){
        e.preventDefault();
        var id = this.id;
        var split_id = id.split("_");
        var deleteindex = split_id[1];

        // Remove <div> with id
        $("#row_" + deleteindex).remove();

    });
    
     $(".removedata").click(function(e){
        e.preventDefault();
            var fullid = $(this).data("id")
            var split_id = fullid.split("_");
            var id = split_id[1];
            
        var confirmation = confirm("are you sure you want to remove the item?");
        if (confirmation) {    
            var token = $("meta[name='csrf-token']").attr("content");
            $.ajax(
            {
                url: "/qualification/"+id,
                type: 'post',
                data: {
                    "id": id,
                    "_token": token,
                },
                success: function (data){
                    $("#rowdata_" + id).remove();
                    alert(data.success);
                },
                error: function () {
                    alert("error");
                }
            });
        }
    });
    //..........................................................Adding a Teaching Subject.........................................................
    $(".addsubject").click(function(e){
        e.preventDefault();
         // Finding total number of elements added
        var total_element = $(".element1").length;
        // last <div> with element1 class id
        var lastid = $(".element1:last").attr("id");
        var split_id = lastid.split("_");
        var nextindex = Number(split_id[1]) + 1;

 
            // Adding new div container after last occurance of element1 class
            $(".element1:last").after("<div class='element1' id='div_"+ nextindex +"'></div>");

            // Adding element to <table>
            var html="";
            html += "<tr id='row1_"+ nextindex +"'>";
            html += "<td>";
            html += "<select name='teachsubject_id[]' id='teachsubject_id"+ nextindex +"' class='form-control form-control-sm' required>";
            html += "<option disabled selected value> -- Select Subject -- </option>"
            html += "<option value=''></option>"
            html += "</select>";
            html += "</td>";
            html += "<td>";
            html += "<input class='form-control form-control-sm' name='periods[]' id='periods"+ nextindex +"' autocomplete='off' required>";
            html += "</td>";
            html += "<td>"
            html += "<button id='remove1_" + nextindex + "' class='btn remove1 btn-danger btn-sm'><i class='fa fa-trash'></i></button>";
            html += "</td>";
            html += "</tr>";
            
            $("#subjecttable").find('tbody').append(html);
        
            //Append to subject dropdown
            var len= 0;
            var subjects = <?php echo isset($teachsubs) ? $teachsubs : 'null'; ?>;
            len = subjects.length;
            if (len>0) {
                for (var i = 0; i<len; i++) {
                    var id = subjects[i].id;
                    var name = subjects[i].cadre;
                    var option2 = "<option value='"+id+"'>"+name+"</option>"; 
                    $("#teachsubject_id"+ nextindex +"").append(option2);                        
                }
            }
    });
    
    // Remove element
    $('.form-card').on('click','.remove1',function(e){
        e.preventDefault();
        var id = this.id;
        var split_id = id.split("_");
        var deleteindex = split_id[1];

        // Remove <div> with id
        $("#row1_" + deleteindex).remove();

    });
    
    $(".removedata1").click(function(e){
        e.preventDefault();
        var fullid = $(this).data("id");
        var split_id = fullid.split("_");
        var id = split_id[1];

        if (!confirm("are you sure you want to remove the item?")) return;

        var token = $("meta[name='csrf-token']").attr("content");

        $.ajax({
            url: "/teachsubject/" + id,
            type: 'DELETE',            // use DELETE verb
            data: {
                "_token": token
            },
            headers: {
                'X-CSRF-TOKEN': token  // extra safety
            },
            success: function (data){
                $("#rowdata1_" + id).remove();
                alert(data.success);
            },
            error: function (xhr, status, error) {
                console.log(xhr);
                alert("Error: " + (xhr.responseJSON?.error || error || "unknown"));
            }
        });
    });
});
    

// Hook edit button — replace prior edit handler (use namespaced event to avoid duplicates)
    $('#edit').off('click.certifyToggle').on('click.certifyToggle', function(e){
        e.preventDefault();

        $('#form').toggleClass('view');

        // toggle readonly/disabled fields as before
        $('input').each(function(){
            var inp = $(this);
            if (inp.attr('readonly')) inp.removeAttr('readonly'); else inp.attr('readonly', 'readonly');
        });
        $('select').each(function(){
            var inp = $(this);
            if (inp.attr('disabled')) inp.removeAttr('disabled'); else inp.attr('disabled', 'disabled');
        });

        // toggle submitdiv display (existing behavior)
        if (submitDiv) {
            if (submitDiv.style.display === "none" || submitDiv.style.display === "") {
                submitDiv.style.display = "block";
            } else {
                submitDiv.style.display = "none";
            }
        }

        // toggle other UI blocks as before
        var addqualifbtn = document.getElementById("addqualifbtn");
        if (addqualifbtn) addqualifbtn.style.display = (addqualifbtn.style.display === "none" || addqualifbtn.style.display === "") ? "block" : "none";

        var subjectbtn = document.getElementById("subjectbtn");
        if (subjectbtn) subjectbtn.style.display = (subjectbtn.style.display === "none" || subjectbtn.style.display === "") ? "block" : "none";

        $('.removedata').css('display', 'block');
        $('.removedata1').css('display', 'block');

        // After toggling, enable/disable checkbox and save button appropriately
        var submitVisible = submitDiv && submitDiv.style.display === 'block';

        if (certifyChk) {
            if (submitVisible) {
                certifyChk.disabled = false; // allow user to check
                // preserve its checked state if any; but keep saveBtn controlled by checkbox change listener
                saveBtn.disabled = !certifyChk.checked;
            } else {
                // exiting edit mode: reset checkbox and disable it, disable save button
                certifyChk.checked = false;
                certifyChk.disabled = true;
                saveBtn.disabled = true;
            }
        } else {
            // no checkbox present: keep existing behaviour (saveBtn visible/enabled when submit shown)
            saveBtn.disabled = !submitVisible;
        }
    });


$(document).ready(function() {
  const $save = $('#saveBtn');
  const $cert = $('#certifyChk');
  const $submitDiv = $('#submitdiv');
  const $addQual = $('#addqualifbtn');
  const $subjectBtn = $('#subjectbtn');

  // initial states
  $submitDiv.hide();
  if ($save.length) $save.prop('disabled', true);
  if ($cert.length) $cert.prop('disabled', true).prop('checked', false);

  // helper: toggle readonly/disabled for inputs/selects
  function toggleFields() {
    $('input').each(function(){
      const $i = $(this);
      if ($i.is('[readonly]')) $i.removeAttr('readonly'); else $i.attr('readonly','readonly');
    });
    $('select').each(function(){
      const $s = $(this);
      if ($s.is(':disabled')) $s.prop('disabled', false); else $s.prop('disabled', true);
    });
  }

  // edit button handler
  $('#edit').off('click.certifyToggle').on('click.certifyToggle', function(e){
    e.preventDefault();

    $('#form').toggleClass('view');
    toggleFields();

    // toggle submit area and related UI
    $submitDiv.toggle();
    $addQual.toggle();
    $subjectBtn.toggle();

    // show remove buttons when editing (keeps your existing behaviour)
    $('.removedata').css('display', 'block');
    $('.removedata1').css('display', 'block');

    const visible = $submitDiv.is(':visible');

    if (visible) {
      // entering edit mode -> enable checkbox (user must check to enable save)
      if ($cert.length) {
        $cert.prop('disabled', false);
        $save.prop('disabled', !$cert.is(':checked'));
      } else {
        $save.prop('disabled', false);
      }
    } else {
      // leaving edit mode -> reset checkbox and disable it, disable save button
      if ($cert.length) {
        $cert.prop('checked', false).prop('disabled', true);
      }
      $save.prop('disabled', true);
    }
  });

  // checkbox change -> only enable save when checkbox checked AND submitDiv visible
  $cert.off('change.certify').on('change.certify', function(){
    const visible = $submitDiv.is(':visible');
    $save.prop('disabled', !(this.checked && visible));
  });

  // keep existing save click logic (modal or submit)
  $save.off('click.saveHandler').on('click.saveHandler', function(){
    <?php if(!empty($employeeDummy)): ?>
      var modal = new bootstrap.Modal(document.getElementById('dummyUpdateModal'));
      modal.show();
    <?php else: ?>
      $('#employee_form').submit();
    <?php endif; ?>
  });

  // When form is submitted, ensure disabled fields are enabled so they get posted
  $('#employee_form').on('submit', function(){
    $(this).find(':disabled').each(function(){
      $(this).removeAttr('disabled');
    });
    // restore masked phone numbers if needed (existing logic kept earlier)
  });
});


</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\VS Projects\SMGT\resources\views/human_resource/createOrUpdate.blade.php ENDPATH**/ ?>